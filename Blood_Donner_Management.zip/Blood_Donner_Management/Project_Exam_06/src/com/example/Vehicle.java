
package com.example;


public class Vehicle {

    private int speed;
 private double regularPrice;
 private String color;

 public Vehicle (int Speed,double regularPrice,String color) {
 this.speed = Speed;
 this.regularPrice = regularPrice;
 this.color = color;
 }

 public double getSalePrice() {
 return regularPrice;
 }
}
