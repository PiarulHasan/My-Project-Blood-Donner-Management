 
package dao;

import java.sql.*;
public class Database_06 {
    public static Connection getConnection(){
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/blooddoner", "root", "");
            return con;
        } catch (Exception e) {
            System.err.println("Connection error");
            return null;
        }
    }
    
    public static void close(Connection con){
        try {
            con.close();
        } catch (Exception ex) {
        }
    }
    
}
