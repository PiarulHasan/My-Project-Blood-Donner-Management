
package CreateFolder;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.Scanner;


public class WriteFile {
    public static void main(String[] args) throws FileNotFoundException {
        Formatter formatter = new Formatter("C:/Users/C5/Desktop/1253196/Samim.txt");
       formatter.format("Bangladesh is a small country");
       formatter.format("Bangladesh is a small country");
       formatter.format("kamal and jamal are tow ");
       formatter.close();
       File file1 = new File("C:/Users/C5/Desktop/1253196/Samim.txt");
       
       Scanner scanner = new Scanner(file1);
       while(scanner.hasNextLine()){
        System.out.println(scanner.nextLine());
    }
    }
}
