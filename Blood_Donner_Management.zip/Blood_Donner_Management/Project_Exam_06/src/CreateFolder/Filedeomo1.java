
package CreateFolder;

import java.io.File;
import java.io.IOException;
import java.util.Formatter;



public class Filedeomo1 {
    public static void main(String[] args) throws IOException {
        File file = new File("C:/Users/C5/Desktop/1253196/Samim.txt");
        file.createNewFile();
       
       
    }
  
}