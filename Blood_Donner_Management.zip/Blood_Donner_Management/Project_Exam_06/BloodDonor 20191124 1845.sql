-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema blooddoner
--

CREATE DATABASE IF NOT EXISTS blooddoner;
USE blooddoner;

--
-- Definition of table `blooddonerinfo`
--

DROP TABLE IF EXISTS `blooddonerinfo`;
CREATE TABLE `blooddonerinfo` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `bloodgroup` varchar(45) NOT NULL,
  `age` decimal(10,0) unsigned NOT NULL,
  `location` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL,
  `contactno` decimal(10,0) unsigned NOT NULL,
  `healthissue` varchar(45) NOT NULL,
  `bloodgivendate` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blooddonerinfo`
--

/*!40000 ALTER TABLE `blooddonerinfo` DISABLE KEYS */;
INSERT INTO `blooddonerinfo` (`id`,`name`,`address`,`gender`,`bloodgroup`,`age`,`location`,`country`,`contactno`,`healthissue`,`bloodgivendate`) VALUES 
 (1,'sdg','sadf','Male','A-','21','asf','Bangladesh','1675867980','Sound ','2019-05-05'),
 (2,'Moshur','Lalbag','Male','A+','28','Dhaka','Bangladesh','1678798546','Sound ','2018-08-21'),
 (3,'Mastura','Malibug','Female','AB+','27','Dhaka','Bangladesh','1678792648','Good ','2018-08-20'),
 (4,'Faysal','Abdullapur','Male','O+','30','Dhaka','Bangladesh','1758792648','Sound ','2018-05-20'),
 (5,'Iftakhar','Gagipur','Male','B-','30','Dhaka','Bangladesh','1759792648','Sound ','2017-05-20');
/*!40000 ALTER TABLE `blooddonerinfo` ENABLE KEYS */;


--
-- Definition of procedure `getDonor`
--

DROP PROCEDURE IF EXISTS `getDonor`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getDonor`(bGrp varchar(45))
BEGIN
select name, age, gender, bloodgroup, bloodgivendate, location, contactno
from blooddonerinfo
where lower(bloodgroup)=lower(bGrp);
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `saveinfo`
--

DROP PROCEDURE IF EXISTS `saveinfo`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `saveinfo`(d integer, nam varchar(45), ad varchar(45), gend varchar(45), bg varchar(45), ag numeric, loc varchar(45), con varchar(45),cn numeric, hi varchar(45), bgd date)
BEGIN
insert into blooddonerinfo(id,name,address,gender,bloodgroup,age,location,country,contactno,healthissue,bloodgivendate) values(d, nam, ad, gend, bg, ag, loc, con, cn, hi, ngd );
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
